import 'package:google_generative_ai/google_generative_ai.dart';

class GeminiService {
  late final GenerativeModel _model;
  
  void init(String apiKey) {
    _model = GenerativeModel(
      model: 'gemini-1.5-flash',
      apiKey: apiKey,
      systemInstruction: Content.text(
        'تو J.A.R.V.I.S هستی، دستیار هوشمند و پیشرفته کاربر. '
        'پاسخ‌هایت باید محترمانه، دقیق، جذاب و هوشمندانه باشد. '
        'زبان اصلی تو فارسی روان است.'
      ),
    );
  }

  Future<String> sendMessage(String prompt) async {
    try {
      final response = await _model.generateContent([Content.text(prompt)]);
      return response.text ?? 'متأسفانه پاسخی دریافت نشد.';
    } catch (e) {
      return 'خطا در ارتباط با هوش مصنوعی: $e';
    }
  }
}
