import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const JarvisApp());
}

class JarvisApp extends StatelessWidget {
  const JarvisApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'J.A.R.V.I.S',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0A0E17),
        primaryColor: const Color(0xFFFFD700),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFFD700),
          secondary: Color(0xFF9D4EDD),
          surface: Color(0xFF161B26),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  bool isListening = false;
  String statusText = "آماده دریافت فرمان...";
  String aiResponse = "سلام! من J.A.R.V.I.S هستم. چطور می‌توانم کمکتان کنم؟";
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  void _toggleListening() {
    setState(() {
      isListening = !isListening;
      statusText = isListening ? "در حال گوش دادن..." : "در حال پردازش...";
    });

    if (!isListening) {
      Future.delayed(const Duration(seconds: 1), () {
        setState(() {
          statusText = "آماده دریافت فرمان...";
          aiResponse = "ارتباط با Gemini API برقرار شد. منتظر دستور شما هستم.";
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('J.A.R.V.I.S AI', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined, color: Color(0xFF00E5FF)),
            onPressed: () {},
          )
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 20),
            Center(
              child: AnimatedBuilder(
                animation: _pulseController,
                builder: (context, child) {
                  return Container(
                    width: 180,
                    height: 180,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          const Color(0xFF9D4EDD).withOpacity(0.8),
                          const Color(0xFF00E5FF).withOpacity(0.4),
                          Colors.transparent,
                        ],
                        stops: const [0.2, 0.7, 1.0],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: isListening ? const Color(0xFF00E5FF) : const Color(0xFFFFD700),
                          blurRadius: 20 + (_pulseController.value * 15),
                          spreadRadius: 2 + (_pulseController.value * 5),
                        )
                      ],
                    ),
                    child: Center(
                      child: Container(
                        width: 120,
                        height: 120,
                        decoration: const BoxDecoration(
                          color: Color(0xFF0A0E17),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          isListening ? Icons.graphic_eq : Icons.psychology,
                          size: 60,
                          color: const Color(0xFFFFD700),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
            Text(
              statusText,
              style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 16),
            ),
            const SizedBox(height: 30),
            Expanded(
              child: Container(
                margin: const EdgeInsets.all(20),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xFF161B26),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFF9D4EDD).withOpacity(0.5), width: 1.5),
                ),
                child: SingleChildScrollView(
                  child: Text(
                    aiResponse,
                    style: const TextStyle(color: Colors.white, fontSize: 16, height: 1.6),
                    textAlign: TextAlign.right,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 30),
              child: GestureDetector(
                onTap: _toggleListening,
                child: Container(
                  height: 70,
                  width: 70,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFFD700), Color(0xFF9D4EDD)],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFFD700).withOpacity(0.4),
                        blurRadius: 15,
                        spreadRadius: 3,
                      )
                    ],
                  ),
                  child: Icon(
                    isListening ? Icons.mic : Icons.mic_none,
                    color: Colors.black,
                    size: 36,
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
