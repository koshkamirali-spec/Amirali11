# پروژه جامع J.A.R.V.I.S (نسخه یکپارچه با GitHub Actions)

این فایل زیپ شامل ساختار کامل پروژه فلاتر به همراه کانفیگ **GitHub Actions** جهت ساخت خودکار فایل **APK** می‌باشد.

## محتویات پروژه:
- `lib/main.dart` -> کد اصلی برنامه و رابط کاربری هولوگرافیک
- `lib/services/gemini_service.dart` -> سرویس اتصال به Gemini API
- `pubspec.yaml` -> لیست وابستگی‌ها و پکیج‌ها
- `.github/workflows/build.yml` -> تنظیمات GitHub Actions برای ساخت APK

## نحوه استفاده در GitHub:
1. فایل زیپ را دانلود و آنزیپ (Extract) کنید.
2. تمام محتویات (شامل پوشه `.github` و `lib` و فایل `pubspec.yaml`) را درون ریپازیتوری خود در GitHub آپلود کنید.
3. به تب **Actions** در گیت‌هاب بروید و منتظر بمانید تا فرایند ساخت فایل APK انجام شود.
